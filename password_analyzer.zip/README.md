# Password Strength Analyzer & Wordlist Generator

## Features
- Analyzes password strength using zxcvbn
- Generates custom wordlists from user inputs
- Adds patterns like numbers, leetspeak, years

## Usage

### 1. Analyze a Password
```bash
python analyzer.py --analyze "MyP@ss123"
```

### 2. Generate Wordlist
```bash
python analyzer.py --genwordlist --inputs name pet dob --output mywordlist.txt
```

## Install Dependencies
```bash
pip install -r requirements.txt
```

## Output
- Wordlist: `mywordlist.txt`
- Strong/weak password analysis score: 0 (weak) to 4 (strong)
